/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.control_de_clientes;

/**
 *
 * @author verin
 */
public class Control_de_clientes {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
